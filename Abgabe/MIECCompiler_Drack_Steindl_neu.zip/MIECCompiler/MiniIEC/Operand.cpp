#include "Operand.h"
namespace MIEC {

	OpClass MIEC::Operand::getOpClass()
	{
		return mClass;
	}

}
