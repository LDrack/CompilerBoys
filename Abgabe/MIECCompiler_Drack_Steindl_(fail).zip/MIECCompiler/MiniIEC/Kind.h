#ifndef _KIND_ENUM__
#define _KIND_ENUM__
namespace MIEC{
	enum class Kind {
		eUndef = 0, 
		eInt = 1,
		eType = 2
	};
}

#endif
