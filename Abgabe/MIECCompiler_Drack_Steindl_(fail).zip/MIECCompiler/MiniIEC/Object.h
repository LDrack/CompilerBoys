#ifndef OBJECT_H_
#define OBJECT_H_

namespace MIEC {
	class Object {
	public:
		virtual ~Object() = default;
	protected:
		Object() = default;
	};
}

#endif
